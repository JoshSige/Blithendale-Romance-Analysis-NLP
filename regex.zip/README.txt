README
COMP 150nlp - Regex and Evil Doings

Name: Joel Reske

=========================
WOAH totally misread the question for #3.

Here's what I ended up doing:
-----------------------------
I added a 'characters' tag to each chapter which lists the top 3 characters
in that chapter in their own tag and how many times they appear in the chapter.

Here's what I had done before re-reading the prompt:
----------------------------------------------------
I thought it'd be really cool to see the important names in the
book and then be able to see where they happen. This is like seeing character
arcs and could be a useful reference for seeing where someone is important in
a book.

All these stats get printed to "Blithedale_Romance_Stats.txt"

The code isn't super clean but it's a cool visualization for the data and You
can really see where certain names or places are prevalent in the book.

One extension to this would be to list by chapter and page instead of by
'percentage through the book' but it's a decent step to make that happen and
this works even better with the visualization because it's a continuous scale.
